var tag = localStorage["tag"];
if ( tag )
	document.write("Tag: <b>"+tag+"</b>");
else
	document.write("AmaTag - Amazon Associate Tag Checker");
